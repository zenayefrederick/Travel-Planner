/**
 * Travel Planner price-search helper (Cloudflare Worker)
 *
 * Keeps your SerpApi key private and returns trimmed flight, hotel and
 * activity results to the Travel Planner app.
 *
 * Settings (Cloudflare dashboard → your Worker → Settings → Variables and Secrets):
 *   SERPAPI_KEY     (Secret)  your SerpApi API key
 *   ALLOWED_ORIGIN  (Text)    the site allowed to use this helper,
 *                             e.g. https://zenayefrederick.github.io
 *                             Separate several with commas. Use * only for testing.
 *
 * Routes:
 *   GET /flights?from=YXE&to=LIS&depart=2026-12-18&return=2026-12-28&currency=CAD&adults=1
 *   GET /hotels?q=Lisbon&checkin=2026-12-19&checkout=2026-12-23&currency=CAD&adults=1
 *   GET /activities?q=Lisbon&currency=CAD
 *
 * Results are cached for 6 hours so repeated searches don't use up your
 * monthly SerpApi allowance.
 */

const SERPAPI = "https://serpapi.com/search.json";
const CACHE_SECONDS = 6 * 60 * 60;

export default {
  async fetch(request, env, ctx) {
    const origin = request.headers.get("Origin") || "";
    const cors = corsHeaders(origin, env.ALLOWED_ORIGIN);

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (request.method !== "GET") return json({ error: "Only GET requests are supported." }, 405, cors);

    // Visiting the helper's address in a browser shows whether it's set up.
    const path0 = new URL(request.url).pathname.replace(/\/+$/, "") || "/";
    if (path0 === "/" || path0 === "/health") {
      return json({
        ok: !!env.SERPAPI_KEY && !!env.ALLOWED_ORIGIN,
        apiKeySet: !!env.SERPAPI_KEY,
        allowedOrigin: env.ALLOWED_ORIGIN || "(not set)"
      }, 200, cors);
    }

    if (!cors["Access-Control-Allow-Origin"]) {
      return json({ error: "This site isn't allowed to use this helper. Add it to ALLOWED_ORIGIN." }, 403, cors);
    }
    if (!env.SERPAPI_KEY) return json({ error: "The helper has no SERPAPI_KEY secret set." }, 500, cors);

    const url = new URL(request.url);
    const route = url.pathname.replace(/\/+$/, "") || "/";
    const p = url.searchParams;

    try {
      let params, shape;
      if (route === "/flights") {
        params = flightParams(p);
        shape = shapeFlights;
      } else if (route === "/hotels") {
        params = hotelParams(p);
        shape = shapeHotels;
      } else if (route === "/activities") {
        params = activityParams(p);
        shape = shapeActivities;
      } else {
        return json({ error: "Unknown route. Use /flights, /hotels or /activities." }, 404, cors);
      }

      // Cache by the SerpApi query (without the key).
      const cacheKey = new Request("https://cache.travel-planner/" + route + "?" + new URLSearchParams(params).toString());
      const cache = caches.default;
      const hit = await cache.match(cacheKey);
      if (hit) {
        const body = await hit.text();
        return new Response(body, { status: 200, headers: { ...cors, "Content-Type": "application/json", "X-Cache": "HIT" } });
      }

      const q = new URLSearchParams({ ...params, api_key: env.SERPAPI_KEY });
      const res = await fetch(SERPAPI + "?" + q.toString());
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.error) {
        const msg = data.error || `SerpApi returned status ${res.status}.`;
        // "No results" from SerpApi is not a failure for the app.
        if (/hasn't returned any results/i.test(msg)) return json({ results: [] }, 200, cors);
        return json({ error: msg }, 502, cors);
      }

      const body = JSON.stringify(shape(data, params));
      ctx.waitUntil(cache.put(cacheKey, new Response(body, {
        headers: { "Content-Type": "application/json", "Cache-Control": `public, max-age=${CACHE_SECONDS}` }
      })));
      return new Response(body, { status: 200, headers: { ...cors, "Content-Type": "application/json", "X-Cache": "MISS" } });
    } catch (err) {
      return json({ error: err.message || "Something went wrong." }, err.status || 500, cors);
    }
  }
};

/* ---------- Request parameters ---------- */

function bad(msg) { const e = new Error(msg); e.status = 400; return e; }
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || "");
const code = (s) => String(s || "").trim().toUpperCase();
const currency = (s) => (/^[A-Z]{3}$/.test(code(s)) ? code(s) : "USD");
const adults = (s) => String(Math.min(9, Math.max(1, parseInt(s, 10) || 1)));

function flightParams(p) {
  const from = code(p.get("from")), to = code(p.get("to"));
  if (!/^[A-Z]{3}$/.test(from) || !/^[A-Z]{3}$/.test(to)) throw bad("Use 3-letter airport codes for from and to, like YXE and LIS.");
  if (!isDate(p.get("depart"))) throw bad("Add a departure date to the trip.");
  const out = {
    engine: "google_flights", departure_id: from, arrival_id: to,
    outbound_date: p.get("depart"), currency: currency(p.get("currency")),
    adults: adults(p.get("adults")), hl: "en"
  };
  if (isDate(p.get("return"))) { out.type = "1"; out.return_date = p.get("return"); }
  else out.type = "2";
  return out;
}

function hotelParams(p) {
  const q = String(p.get("q") || "").trim().slice(0, 120);
  if (!q) throw bad("Add a destination to the trip.");
  if (!isDate(p.get("checkin")) || !isDate(p.get("checkout"))) throw bad("Hotels need check-in and check-out dates.");
  const out = {
    engine: "google_hotels", q, check_in_date: p.get("checkin"), check_out_date: p.get("checkout"),
    currency: currency(p.get("currency")), adults: adults(p.get("adults")), hl: "en"
  };
  if (["3", "8", "13"].includes(p.get("sort"))) out.sort_by = p.get("sort");
  return out;
}

function activityParams(p) {
  const q = String(p.get("q") || "").trim().slice(0, 120);
  if (!q) throw bad("Add a destination to the trip.");
  return { engine: "google_maps", type: "search", q: "things to do in " + q, hl: "en" };
}

/* ---------- Response shaping ---------- */

function shapeFlights(data, params) {
  const list = [...(data.best_flights || []).map((f) => ({ ...f, _best: true })), ...(data.other_flights || [])];
  const searchUrl = "https://www.google.com/travel/flights?q=" + encodeURIComponent(
    `Flights from ${params.departure_id} to ${params.arrival_id} on ${params.outbound_date}` +
    (params.return_date ? ` through ${params.return_date}` : " one way")
  );
  return {
    roundTrip: params.type === "1",
    bookingUrl: searchUrl,
    results: list.slice(0, 12).map((f) => {
      const legs = f.flights || [];
      const first = legs[0] || {}, last = legs[legs.length - 1] || {};
      return {
        best: !!f._best,
        price: typeof f.price === "number" ? f.price : null,
        airlines: [...new Set(legs.map((l) => l.airline).filter(Boolean))],
        logo: f.airline_logo || first.airline_logo || "",
        departTime: first.departure_airport?.time || "",
        arriveTime: last.arrival_airport?.time || "",
        fromCode: first.departure_airport?.id || params.departure_id,
        toCode: last.arrival_airport?.id || params.arrival_id,
        durationMin: f.total_duration || null,
        stops: Math.max(0, legs.length - 1),
        layovers: (f.layovers || []).map((l) => l.id || l.name).filter(Boolean),
        flightNumbers: legs.map((l) => l.flight_number).filter(Boolean)
      };
    })
  };
}

function shapeHotels(data, params) {
  const bookingUrl = data.search_metadata?.google_hotels_url ||
    "https://www.google.com/travel/search?q=" + encodeURIComponent(params.q);
  return {
    bookingUrl,
    results: (data.properties || []).slice(0, 12).map((h) => ({
      name: h.name || "Unnamed stay",
      type: h.type || "",
      stars: h.extracted_hotel_class || null,
      rating: h.overall_rating || null,
      reviews: h.reviews || null,
      perNight: h.rate_per_night?.extracted_lowest ?? null,
      total: h.total_rate?.extracted_lowest ?? null,
      image: h.images?.[0]?.thumbnail || "",
      link: h.link || bookingUrl
    }))
  };
}

function shapeActivities(data) {
  return {
    results: (data.local_results || []).slice(0, 12).map((a) => ({
      name: a.title || "Unnamed place",
      type: a.type || (a.types || [])[0] || "",
      rating: a.rating || null,
      reviews: a.reviews || null,
      priceText: a.price || "",
      price: typeof a.extracted_price === "number" ? a.extracted_price : null,
      description: a.description || "",
      address: a.address || "",
      image: a.thumbnail || "",
      link: a.place_id ? "https://www.google.com/maps/place/?q=place_id:" + a.place_id : (a.website || "")
    }))
  };
}

/* ---------- Helpers ---------- */

function corsHeaders(origin, allowed) {
  const list = String(allowed || "").split(",").map((s) => s.trim().replace(/\/+$/, "")).filter(Boolean);
  const ok = list.includes("*") || (origin && list.includes(origin));
  return {
    ...(ok ? { "Access-Control-Allow-Origin": list.includes("*") ? "*" : origin } : {}),
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}

function json(obj, status, headers) {
  return new Response(JSON.stringify(obj), { status, headers: { ...headers, "Content-Type": "application/json" } });
}
