-- Travel Planner: trips table for cloud sync.
-- Run this once in your Supabase project: SQL Editor → New query → paste → Run.

create table if not exists public.trips (
  user_id    uuid        not null default auth.uid() references auth.users (id) on delete cascade,
  id         text        not null,
  data       jsonb       not null default '{}'::jsonb,
  deleted    boolean     not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, id)
);

-- Row Level Security: each person can only see and change their own trips.
alter table public.trips enable row level security;

drop policy if exists "Read own trips" on public.trips;
create policy "Read own trips" on public.trips
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Add own trips" on public.trips;
create policy "Add own trips" on public.trips
  for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists "Update own trips" on public.trips;
create policy "Update own trips" on public.trips
  for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

drop policy if exists "Delete own trips" on public.trips;
create policy "Delete own trips" on public.trips
  for delete to authenticated using ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.trips to authenticated;
